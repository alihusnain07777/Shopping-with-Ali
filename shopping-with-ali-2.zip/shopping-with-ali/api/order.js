const P=require('./_data');
module.exports=(req,res)=>{
if(req.method!=='POST')return res.status(405).json({error:'POST only'});
const b=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{});
const c=b.customer||{};
if(!c.name||!/^(\+?92|0)?3\d{9}$/.test(String(c.phone||'').replace(/[\s-]/g,''))||!c.city||!c.address)return res.status(400).json({error:'Name, valid Pakistani mobile number, city and address are required.'});
let sub=0;const items=[];
for(const i of b.items||[]){const p=P.find(x=>String(x.id)===String(i.id));if(p&&i.qty>0){const q=Math.min(10,i.qty|0);sub+=p.price*q;items.push({id:p.id,name:p.name,qty:q,price:p.price});}}
if(!items.length)return res.status(400).json({error:'Cart is empty.'});
const ship=sub>=5000?0:200,id='SWA-'+Date.now().toString(36).toUpperCase();
console.log('ORDER',id,c,items);
res.status(200).json({id,items,subtotal:sub,shipping:ship,total:sub+ship});};
