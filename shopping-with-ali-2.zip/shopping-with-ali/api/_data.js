module.exports=[
["Samsung Galaxy A15 128GB","Mobiles","📱",52999,59999,4.5,"6.5in AMOLED, 50MP camera, 5000mAh battery. 1 year warranty."],
["Wireless Earbuds Pro","Electronics","🎧",2499,3999,4.3,"Bluetooth 5.3, noise reduction, 24 hour battery case."],
["Smart Watch Series 9","Electronics","⌚",3999,6499,4.4,"Calls, heart rate, 1.9in display, waterproof."],
["Mens Lawn 3 Piece Suit","Fashion","👕",3299,4500,4.6,"Premium summer lawn, stitched or unstitched."],
["Ladies Embroidered Kurti","Fashion","👗",2799,3800,4.7,"Chiffon embroidery, 3 sizes, colour fast."],
["Running Sports Shoes","Fashion","👟",2999,4999,4.4,"Light weight, anti slip sole, all sizes."],
["Non-Stick Cookware Set","Home","🍳",4499,6999,4.5,"7 piece set, induction friendly."],
["Electric Kettle 1.8L","Home","☕",1899,2799,4.2,"Auto shut off, stainless steel."],
["Laptop Backpack Water Proof","Bags","🎒",1799,2999,4.6,"USB charging port, fits 15.6in laptop."],
["Beauty Care Gift Box","Beauty","💄",2199,3200,4.5,"Face wash, serum, moisturizer, lip balm."],
["Kids Remote Control Car","Kids","🚗",1599,2499,4.3,"Rechargeable, 2.4GHz, strong body."],
["Power Bank 20000mAh","Electronics","🔋",3299,4999,4.6,"Fast charging, dual USB, LED display."]
].map((p,i)=>({id:i+1,name:p[0],category:p[1],emoji:p[2],price:p[3],oldPrice:p[4],rating:p[5],desc:p[6],stock:25}));
