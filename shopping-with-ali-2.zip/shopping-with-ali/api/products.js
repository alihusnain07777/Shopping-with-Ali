const P=require('./_data');
module.exports=(req,res)=>{const{q='',category=''}=req.query||{};
const r=P.filter(p=>(!category||p.category===category)&&p.name.toLowerCase().includes(String(q).toLowerCase()));
res.setHeader('Cache-Control','s-maxage=60');res.status(200).json({products:r,categories:[...new Set(P.map(p=>p.category))]});};
