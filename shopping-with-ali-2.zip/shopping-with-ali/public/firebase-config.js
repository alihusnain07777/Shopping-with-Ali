// Firebase web config (public hota hai; asli hifazat Firestore Rules se hoti hai).
window.FB_CONFIG = {
  apiKey: "AIzaSyBsKJr299hBCZxjwJmvWP7_-wqgA3JiQvQ",
  authDomain: "shopping-with-ali.firebaseapp.com",
  projectId: "shopping-with-ali",
  storageBucket: "shopping-with-ali.firebasestorage.app",
  messagingSenderId: "405301017833",
  appId: "1:405301017833:web:d16f6ee857331c8f554478"
};
